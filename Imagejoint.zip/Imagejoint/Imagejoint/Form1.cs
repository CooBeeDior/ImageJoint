﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Imagejoint
{
    public partial class Form1 : Form
    {
        ImageList imageList = new ImageList();
        List<Image> picList = new List<Image>();
        public Form1()
        {
            InitializeComponent();
        }

        private void addImage_Click(object sender, EventArgs e)
        {

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "图片文件(*.bmp,*.jpg,*.png,*.gif）|*.bmp;*.jpg;*.png;*.gif|所有文件(*.*)|*.*";
            openFileDialog.Title = "选择图片";
            openFileDialog.Multiselect = true;
            //string picNames = string.Empty;
            var showDialogRes = openFileDialog.ShowDialog();
            if (showDialogRes == DialogResult.OK)
            {
                listView1.LargeImageList = imageList;
                imageList.ImageSize = new Size(150, 150);
                foreach (string fileName in openFileDialog.FileNames)
                {
                    //picNames += fileName + Environment.NewLine;
                    Image image = Image.FromFile(fileName);
                    //Size isize = image.Size;
                    //int width = image.Width * 120 / image.Height > 255 ? 255 : image.Width * 120 / image.Height;
                    //imageList.ImageSize = new Size(width, 120);
                    imageList.Images.Add(image);
                    picList.Add(image);
                    ListViewItem myitem = new ListViewItem(Path.GetFileName(fileName));
                    myitem.ImageIndex = imageList.Images.Count - 1;
                    listView1.Items.Add(myitem);

                }

                // MessageBox.Show(picNames);
                deal();
            }
            else
            {

            }

        }

        private void removeBtn_Click(object sender, EventArgs e)
        {
            removeListItem();


        }

        private void removeListItem()
        {
            var imageItems = listView1.SelectedItems;
            foreach (ListViewItem item in imageItems)
            {
                if (listView1.SelectedItems.Contains(item))
                {
                    int indexDel = listView1.Items.IndexOf(listView1.FocusedItem);
                    if (listView1.SelectedItems.Count != 0)
                    {
                        listView1.Items.RemoveAt(indexDel);//删除
                        picList.RemoveAt(indexDel);
                        imageList.Images.RemoveAt(indexDel);
                    }
                }

            }
            listViewFocus();
            if (listView1.Items.Count > 0)
            {
                deal();
            }

        }


        private void listViewFocus()
        {
            if (listView1.SelectedIndices.Count > 0)
            {
                this.listView1.Focus();
                this.listView1.Items[0].Selected = true;
            }

        }

        private void saveBtn_Click(object sender, EventArgs e)
        {
            var outputImage = deal();
            if (outputImage == null)
            {
                return;
            }
            string temp = "temp";
            if (!Directory.Exists(temp))
            {
                Directory.CreateDirectory(temp);
            }
            string outputPath = Path.Combine(temp, $"{Guid.NewGuid()}.jpg");
            outputImage.Save(outputPath);
            Process.Start(outputPath);


        }
        private Image deal()
        {
            if (picList.Count == 0)
            {
                MessageBox.Show("请先添加照片", "保存失败", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return null;
            }
            int width = 0, height = 0;
            IList<Image> tempImages = new List<Image>();
            foreach (var image in picList)
            {
                var w = image.Width * 500 / image.Height;//> 800 ? 800 : image.Width * 500 / image.Height;
                var tempImage = imgCompress(image, new Size(w, 500));
                if (tempImage.Width > width)
                {
                    width = tempImage.Width;
                }
                height += tempImage.Height;
                tempImages.Add(tempImage);

            }

            Image outputImage = new Bitmap(width, height);
            Graphics graph = Graphics.FromImage(outputImage);
            //初始化这个大图
            graph.DrawImage(outputImage, 0, 0);

            int currentHeight = 0;
            foreach (var image in tempImages)
            {
                graph.DrawImage(image, 0, currentHeight);
                currentHeight += image.Height;
            }

            pictureBox1.Image = outputImage;
            return outputImage;

        }
        private void clearBtn_Click(object sender, EventArgs e)
        {
            if (listView1.LargeImageList != null && listView1.LargeImageList.Images != null)
            {
                listView1.LargeImageList.Images.Clear();
            }
            if (imageList.Images.Count > 0)
            {
                imageList.Images.Clear();
            }
            if (listView1.Items.Count > 0)
            {
                listView1.Items.Clear();
            }
            if (picList.Count > 0)
            {
                picList.Clear();
            }
            pictureBox1.Image = null;

        }

        private void listView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                contextMenuStrip1.Show(listView1, e.Location);//鼠标右键按下弹出菜单
            }
        }



        private void contextMenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            var selectIndex = listView1.SelectedItems[0].ImageIndex;
            bool changed = false;

            if (e.ClickedItem.Tag?.ToString() == "toLeft")
            {
                picList[selectIndex].RotateFlip(RotateFlipType.Rotate270FlipNone);
                imageList.Images.Clear();
                foreach (var item in picList)
                {
                    imageList.Images.Add(item);
                }
                changed = true;
            }
            else if (e.ClickedItem.Tag?.ToString() == "toRight")
            {


                picList[selectIndex].RotateFlip(RotateFlipType.Rotate90FlipNone);

                imageList.Images.Clear();
                foreach (var item in picList)
                {
                    imageList.Images.Add(item);
                }
                changed = true;
            }
            else if (e.ClickedItem.Tag?.ToString() == "remove")
            {
                removeListItem();
                changed = true;
            }
            if (changed)
            {
                deal();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var selectItenms = listView1.SelectedItems;
            if (selectItenms.Count > 0)
            {
                foreach (ListViewItem item in selectItenms)
                {
                    var selectIndex = item.ImageIndex;
                    picList[selectIndex].RotateFlip(RotateFlipType.Rotate270FlipNone);
                    imageList.Images.Clear();
                    foreach (var image in picList)
                    {
                        imageList.Images.Add(image);
                    }
                }
                deal();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var selectItenms = listView1.SelectedItems;
            if (selectItenms.Count > 0)
            {
                foreach (ListViewItem item in selectItenms)
                {
                    var selectIndex = item.ImageIndex;
                    picList[selectIndex].RotateFlip(RotateFlipType.Rotate90FlipNone);
                    imageList.Images.Clear();
                    foreach (var image in picList)
                    {
                        imageList.Images.Add(image);
                    }
                }
                deal();
            }
        }

        /// <summary>
        /// 图片压缩功能
        /// </summary>
        /// <param name="sourceImage">原图</param>
        /// <param name="targetSize">目标压缩尺寸</param>
        /// <returns></returns>
        private Image imgCompress(Image sourceImage, Size targetSize)  ///图片压缩功能
        {
            int targetWidth = targetSize.Width, targetHeight = targetSize.Height;  //图片转换的目标的尺寸；由于图片原有的比例问题，目标尺寸不等于最终的尺寸。
            int width;//图片最终的宽
            int height;//图片最终的高
            try
            {
                System.Drawing.Imaging.ImageFormat format = sourceImage.RawFormat;
                Bitmap targetPicture = new Bitmap(targetWidth, targetHeight);
                Graphics g = Graphics.FromImage(targetPicture);
                g.Clear(Color.White);
                //计算缩放图片的大小
                if (sourceImage.Width > targetWidth && sourceImage.Height <= targetHeight)
                {
                    width = targetWidth;
                    height = (width * sourceImage.Height) / sourceImage.Width;
                }
                else if (sourceImage.Width <= targetWidth && sourceImage.Height > targetHeight)
                {
                    height = targetHeight;
                    width = (height * sourceImage.Width) / sourceImage.Height;
                }
                else if (sourceImage.Width <= targetWidth && sourceImage.Height <= targetHeight)
                {
                    width = sourceImage.Width;
                    height = sourceImage.Height;
                }
                else
                {
                    width = targetWidth;
                    height = (width * sourceImage.Height) / sourceImage.Width;
                    if (height > targetHeight)
                    {
                        height = targetHeight;
                        width = (height * sourceImage.Width) / sourceImage.Height;
                    }
                }
                g.DrawImage(sourceImage, (targetWidth - width) / 2, (targetHeight - height) / 2, width, height);
                sourceImage = targetPicture;
                return targetPicture;
            }
            catch (Exception ex)
            {
            }
            return null;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
